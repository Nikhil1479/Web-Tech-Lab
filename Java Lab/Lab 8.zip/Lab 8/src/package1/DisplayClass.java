package package1;

public class DisplayClass {
    public void display(){


        System.out.println("example of the package1 ");

    }
}