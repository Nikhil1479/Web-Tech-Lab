import package1.*;

public class UsePackage {
    public static void main(String[] args) {
        DisplayClass ds=new DisplayClass();
        ds.display();
    }
}